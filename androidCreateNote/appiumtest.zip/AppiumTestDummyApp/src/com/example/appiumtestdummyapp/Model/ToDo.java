package com.example.appiumtestdummyapp.Model;

public class ToDo {
	private String item;
	
	public ToDo(String item) {
		this.setItem(item);
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}
}
